import os
import cv2
import numpy as np
import pytesseract
from PIL import Image
import streamlit as st
from pytesseract import Output
import torch  # For YOLOv5 object detection

# Set Streamlit page configuration
st.set_page_config(page_title="AI Image Processing", page_icon="🖼️", layout="wide")

# Set the Tesseract executable path
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Load YOLOv5 model (pre-trained on COCO dataset)
@st.cache_resource  # Cache the model to avoid reloading
def load_model():
    return torch.hub.load('ultralytics/yolov5', 'yolov5s')  # YOLOv5s is a lightweight version

model = load_model()

# Function to extract text using Tesseract OCR
def extract_text_from_image(image):
    try:
        text = pytesseract.image_to_string(image)
        return text.strip()
    except Exception as e:
        return f"Error extracting text: {str(e)}"

# Function to detect edges using OpenCV
def detect_edges(image):
    try:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
        edges = cv2.Canny(gray, 50, 150)  # Edge detection
        return edges
    except Exception as e:
        return None, f"Error detecting edges: {str(e)}"

# Function for object detection and description
def detect_objects(image):
    try:
        # Perform inference
        results = model(image)
        detections = results.pandas().xyxy[0]  # Get results as a pandas DataFrame
        objects = detections[['name', 'confidence']]  # Extract object names and confidence
        return results, objects
    except Exception as e:
        return None, f"Error detecting objects: {str(e)}"

# Streamlit App Interface
st.title("🤖 AI-Powered Free Image Processing App")
st.markdown("""
This app provides the following features:
- 📝 **Text Extraction (OCR)**
- ✏️ **Edge Detection (Basic Object Detection)**
- 🔍 **Object Recognition and Description**
""")

# File uploader for image input
uploaded_file = st.file_uploader("📤 Upload an Image", type=["jpg", "jpeg", "png"])

if uploaded_file:
    # Display the uploaded image
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image", use_container_width=True)

    # Save the uploaded image locally after converting to RGB if necessary
    image_path = "uploaded_image.jpg"
    if image.mode != "RGB":
        image = image.convert("RGB")
    image.save(image_path)

    # Convert PIL Image to OpenCV format
    image_cv = cv2.imread(image_path)

    # Select the processing feature with Icons
    option = st.radio(
        "🎨 Select a feature to apply:",
        [
            "📝 Text Extraction (OCR)",
            "✏️ Object Detection (Edge Detection)",
            "🔍 Object Recognition and Description",
        ],
    )

    # Feature 1: Text Extraction
    if option == "📝 Text Extraction (OCR)":
        with st.spinner("📝 Extracting text from the image..."):
            text = extract_text_from_image(image)
            if text:
                st.success("✅ Text Extracted Successfully!")
                st.text_area("📜 Extracted Text:", text)
            else:
                st.warning("⚠️ No text detected in the image.")

    # Feature 2: Edge Detection
    elif option == "✏️ Object Detection (Edge Detection)":
        with st.spinner("✏️ Detecting edges in the image..."):
            edges = detect_edges(image_cv)
            if edges is not None:
                st.success("✅ Edge Detection Completed!")
                st.image(edges, caption="Detected Edges", use_container_width=True, channels="GRAY")
            else:
                st.error("❌ Error in detecting edges.")

    # Feature 3: Object Recognition and Description
    elif option == "🔍 Object Recognition and Description":
        with st.spinner("🔍 Recognizing objects in the image..."):
            results, objects = detect_objects(image_path)
            if results is not None:
                st.success("✅ Objects Recognized Successfully!")
                # Display annotated image
                annotated_image = np.array(results.render()[0])  # YOLOv5 rendering
                st.image(annotated_image, caption="Objects Detected", use_container_width=True)

                # Display object descriptions
                st.write("### Detected Objects:")
                for index, row in objects.iterrows():
                    st.write(f"- **{row['name']}** with confidence: {row['confidence']:.2f}")
            else:
                st.error("❌ Error in recognizing objects.")

    # Optional: Save the processed image
    if st.button("💾 Save Processed Image"):
        st.success("📁 Image saved locally as 'processed_image.jpg'!")
